package com.example.appbluetooth;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private Button btnOn, btnOff, btnDisc, btnList;
    private ListView listV1;
    BluetoothAdapter bluetoothAdapter=null;
    private static final int REQUEST_ENABLED = 0;
    private static final int REQUEST_DISCOVERABLE = 0;
    private static final int SOLICITA_ATIVACAO = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnOn = findViewById(R.id.btnOn);
        btnOff = findViewById(R.id.btnOff);
        btnDisc = findViewById(R.id.btnDisc);
        btnList = findViewById(R.id.btnList);
        listV1 = findViewById(R.id.listV1);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(bluetoothAdapter ==null){
            Toast.makeText(this, "Bluetooth not supperted!",
                    Toast.LENGTH_LONG).show();
            finish();
        }else{
            Intent it = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(it, SOLICITA_ATIVACAO);
        }
        if(!bluetoothAdapter.isDiscovering()){
            Intent it=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            startActivityForResult(it,REQUEST_DISCOVERABLE);
        }
        btnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(it, REQUEST_ENABLED);
            }
        });
        btnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bluetoothAdapter.disable();
            }
        });
        btnDisc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!bluetoothAdapter.isDiscovering()){
                    Intent it=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(it,REQUEST_DISCOVERABLE);
                }
            }
        });
        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // retorna os dispositivos pareados
                bluetoothAdapter=BluetoothAdapter.getDefaultAdapter();
                bluetoothAdapter.startDiscovery();
                IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(receiver, filter);
                ArrayAdapter<String> arrayBluetooth = new ArrayAdapter<String>
                        (MainActivity.this,android.R.layout.simple_list_item_1);
                Toast.makeText(MainActivity.this, "Gerar a Lista!", Toast.LENGTH_LONG).show();
                           // retorna os dispositivos pareados
                Set<BluetoothDevice> pairedDevices =
                        bluetoothAdapter.getBondedDevices();
                if (pairedDevices.size() > 0) {
                    Toast.makeText(MainActivity.this, "Existem dispositivos",
                            Toast.LENGTH_LONG).show();

                } else{
                    Toast.makeText(MainActivity.this,
                            "Não existem dispositivos",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    // Create a BroadcastReceiver for ACTION_FOUND.
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            ArrayAdapter<String> arrayBluetooth = new ArrayAdapter<String>
                    (MainActivity.this,android.R.layout.simple_list_item_1);
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Discovery has found a device. Get the BluetoothDevice
                Set<BluetoothDevice> pairedDevices =
                        bluetoothAdapter.getBondedDevices();
                for (BluetoothDevice device : pairedDevices) {
                    // adiciona em um adapter para mostrar em uma ListView , como exemplo
                    arrayBluetooth.add(device.getName() + " " + device.getAddress());
                }
            }
            listV1.setAdapter(arrayBluetooth);
        }
    };
    @Override
    protected void onActivityResult(int resquestCode,int resultCode, Intent data) {
        super.onActivityResult(resquestCode, resultCode, data);
        switch (resquestCode) {
            case SOLICITA_ATIVACAO:
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(this, "Bluetooth ativado!",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Bluetooth não ativado!",
                            Toast.LENGTH_LONG).show();
                    finish();
                }
                break;
        }
    }
}
