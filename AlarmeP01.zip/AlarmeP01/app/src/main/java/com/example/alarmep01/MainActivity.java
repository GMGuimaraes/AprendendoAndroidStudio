package com.example.alarmep01;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnOneTime, btnRepeat, btnCancel;
    AlarmManager alarmManager;
    PendingIntent pendingIntent;
    boolean isRepeat=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnOneTime=findViewById(R.id.btnOneTime);
        btnRepeat=findViewById(R.id.btnRepeat);
        btnCancel=findViewById(R.id.btnCancel);
        btnOneTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRepeat=false;
                startAlarm();
            }
        });
        btnRepeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRepeat=true;
                startAlarm();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(alarmManager!=null){
                    alarmManager.cancel(pendingIntent);
                }
            }
        });
    }
    public void startAlarm() {
        alarmManager = (AlarmManager)
                this.getSystemService(Context.ALARM_SERVICE);
        Intent intent=new Intent(MainActivity.this,
                AlarmeToastReceiver.class);
        pendingIntent=PendingIntent.getBroadcast(this,0,
                intent,0);
        if(!isRepeat){
            alarmManager.set(AlarmManager.RTC,
                    SystemClock.elapsedRealtime()+60*1000,pendingIntent);
        }else{
            alarmManager.setInexactRepeating(AlarmManager.RTC,
                    SystemClock.elapsedRealtime()+60*1000,
                    60*1000*1/2,
                    pendingIntent);
        }
    }
}